package brockstar17.samples.ex2;

/**
 * This class will house the math and logic used for <br>
 * the calculator to perform the operation on enter.
 * 
 * @author Brock
 *
 */
public class FancyMath {

}
